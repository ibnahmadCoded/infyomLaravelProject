

<!-- Title Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('title', 'Title:'); ?>

    <?php echo Form::text('title', null, ['class' => 'form-control']); ?>

</div>

<!-- Organisation Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('organisation_id', 'Organisation Id:'); ?>

    <?php echo Form::number('organisation_id', null, ['class' => 'form-control']); ?>

</div>

<!-- Country Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('country_id', 'Country Id:'); ?>

    <?php echo Form::number('country_id', null, ['class' => 'form-control']); ?>

</div>

<!-- Skills Required Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('skills_required', 'Skills Required:'); ?>

    <?php echo Form::text('skills_required', null, ['class' => 'form-control']); ?>

</div>

<!-- Description Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('description', 'Description:'); ?>

    <?php echo Form::textarea('description', null, ['class' => 'form-control']); ?>

</div>

<!-- Status Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('status', 'Status:'); ?>

    <?php echo Form::text('status', null, ['class' => 'form-control']); ?>

</div>

<!-- Work Type Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('work_type', 'Work Type:'); ?>

    <?php echo Form::text('work_type', null, ['class' => 'form-control']); ?>

</div>

<!-- Job Type Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('job_type', 'Job Type:'); ?>

    <?php echo Form::text('job_type', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('jobs.index'); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH C:\xampp\htdocs\laravel-jobs\resources\views/jobs/fields.blade.php ENDPATH**/ ?>
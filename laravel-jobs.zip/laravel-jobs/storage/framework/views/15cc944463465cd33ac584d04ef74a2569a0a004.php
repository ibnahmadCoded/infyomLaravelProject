<!-- User Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('user_id', 'User Id:'); ?>

    <?php echo Form::number('user_id', null, ['class' => 'form-control']); ?>

</div>

<!-- Balance Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('balance', 'Balance:'); ?>

    <?php echo Form::number('balance', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('accounts.index'); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH C:\xampp\htdocs\laravel-jobs\resources\views/accounts/fields.blade.php ENDPATH**/ ?>
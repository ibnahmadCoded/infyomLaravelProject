<li class="<?php echo e(Request::is('jobs*') ? 'active' : ''); ?>">
    <a href="<?php echo route('jobs.index'); ?>"><i class="fa fa-edit"></i><span>Job Seekers</span></a>
</li>

<li class="<?php echo e(Request::is('jobs*') ? 'active' : ''); ?>">
    <a href="<?php echo route('jobs.index'); ?>"><i class="fa fa-edit"></i><span>Open Jobs</span></a>
</li>

<li class="<?php echo e(Request::is('jobs*') ? 'active' : ''); ?>"><!--jobs I applied for and jobs I created -->
    <a href="<?php echo route('jobs.index'); ?>"><i class="fa fa-edit"></i><span>My Jobs</span></a>
</li>


<li class="<?php echo e(Request::is('skills*') ? 'active' : ''); ?>">
    <a href="<?php echo route('skills.index'); ?>"><i class="fa fa-edit"></i><span>My Skills</span></a>
</li>

<li class="<?php echo e(Request::is('accounts*') ? 'active' : ''); ?>">
    <a href="<?php echo route('accounts.index'); ?>"><i class="fa fa-edit"></i><span>My Account</span></a>
</li>

<li class="<?php echo e(Request::is('invitations*') ? 'active' : ''); ?>">
    <a href="<?php echo route('invitations.index'); ?>"><i class="fa fa-edit"></i><span>My Invitations</span></a>
</li>

<li class="<?php echo e(Request::is('organisations*') ? 'active' : ''); ?>">
    <a href="<?php echo route('organisations.index'); ?>"><i class="fa fa-edit"></i><span>My Organisations</span></a>
</li>


<!-- Admin Section -->

<?php if(Auth::user()->role_id < 3): ?>
<li class="header">ADMIN</li>

<li class="<?php echo e(Request::is('roles*') ? 'active' : ''); ?>">
    <a href="<?php echo route('roles.index'); ?>"><i class="fa fa-edit"></i><span>Roles</span></a>
</li>

<li class="<?php echo e(Request::is('organisations*') ? 'active' : ''); ?>">
    <a href="<?php echo route('organisations.index'); ?>"><i class="fa fa-edit"></i><span>Organisations</span></a>
</li>

<li class="<?php echo e(Request::is('accounts*') ? 'active' : ''); ?>">
    <a href="<?php echo route('accounts.index'); ?>"><i class="fa fa-edit"></i><span>Accounts</span></a>
</li>

<li class="<?php echo e(Request::is('users*') ? 'active' : ''); ?>">
    <a href="<?php echo route('users.index'); ?>"><i class="fa fa-edit"></i><span>Users</span></a>
</li>

<li class="<?php echo e(Request::is('skills*') ? 'active' : ''); ?>">
    <a href="<?php echo route('skills.index'); ?>"><i class="fa fa-edit"></i><span>Skills</span></a>
</li>

<li class="<?php echo e(Request::is('jobs*') ? 'active' : ''); ?>"><!--jobs I applied for and jobs I created -->
    <a href="<?php echo route('jobs.index'); ?>"><i class="fa fa-edit"></i><span>Jobs</span></a>
</li>

<li class="<?php echo e(Request::is('invitations*') ? 'active' : ''); ?>">
    <a href="<?php echo route('invitations.index'); ?>"><i class="fa fa-edit"></i><span>Invitations</span></a>
</li>

<li class="<?php echo e(Request::is('failedJobs*') ? 'active' : ''); ?>">
    <a href="<?php echo route('failedJobs.index'); ?>"><i class="fa fa-edit"></i><span>Failed Jobs</span></a>
</li>

<li class="<?php echo e(Request::is('countries*') ? 'active' : ''); ?>">
    <a href="<?php echo route('countries.index'); ?>"><i class="fa fa-edit"></i><span>Countries</span></a>
</li>

<?php endif; ?>

<!--
    
<li class="<?php echo e(Request::is('organisationUsers*') ? 'active' : ''); ?>">
    <a href="<?php echo route('organisationUsers.index'); ?>"><i class="fa fa-edit"></i><span>Organisation Users</span></a>
</li>

-->




<?php /**PATH C:\xampp\htdocs\laravel-jobs\resources\views/layouts/menu.blade.php ENDPATH**/ ?>
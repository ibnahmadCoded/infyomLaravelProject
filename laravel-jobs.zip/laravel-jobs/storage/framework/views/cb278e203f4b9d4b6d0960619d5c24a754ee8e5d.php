<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<!-- Currency Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('currency', 'Currency:'); ?>

    <?php echo Form::text('currency', null, ['class' => 'form-control']); ?>

</div>

<!-- Code Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('code', 'Code:'); ?>

    <?php echo Form::text('code', null, ['class' => 'form-control']); ?>

</div>

<!-- Phone Ext Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('phone_ext', 'Phone Ext:'); ?>

    <?php echo Form::text('phone_ext', null, ['class' => 'form-control']); ?>

</div>

<!-- Flag Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('flag', 'Flag:'); ?>

    <?php echo Form::text('flag', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('countries.index'); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH C:\xampp\htdocs\laravel-jobs\resources\views/countries/fields.blade.php ENDPATH**/ ?>
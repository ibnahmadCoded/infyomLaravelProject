<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $job->id; ?></p>
</div>

<!-- User Id Field -->
<div class="form-group">
    <?php echo Form::label('user_id', 'User Id:'); ?>

    <p><?php echo $job->user_id; ?></p>
</div>

<!-- Organisation Id Field -->
<div class="form-group">
    <?php echo Form::label('organisation_id', 'Organisation Id:'); ?>

    <p><?php echo $job->organisation_id; ?></p>
</div>

<!-- Country Id Field -->
<div class="form-group">
    <?php echo Form::label('country_id', 'Country Id:'); ?>

    <p><?php echo $job->country_id; ?></p>
</div>

<!-- Title Field -->
<div class="form-group">
    <?php echo Form::label('title', 'Title:'); ?>

    <p><?php echo $job->title; ?></p>
</div>

<!-- Skills Required Field -->
<div class="form-group">
    <?php echo Form::label('skills_required', 'Skills Required:'); ?>

    <p><?php echo $job->skills_required; ?></p>
</div>

<!-- Description Field -->
<div class="form-group">
    <?php echo Form::label('description', 'Description:'); ?>

    <p><?php echo $job->description; ?></p>
</div>

<!-- Status Field -->
<div class="form-group">
    <?php echo Form::label('status', 'Status:'); ?>

    <p><?php echo $job->status; ?></p>
</div>

<!-- Work Type Field -->
<div class="form-group">
    <?php echo Form::label('work_type', 'Work Type:'); ?>

    <p><?php echo $job->work_type; ?></p>
</div>

<!-- Job Type Field -->
<div class="form-group">
    <?php echo Form::label('job_type', 'Job Type:'); ?>

    <p><?php echo $job->job_type; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $job->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $job->updated_at; ?></p>
</div>

<!-- Deleted At Field -->
<div class="form-group">
    <?php echo Form::label('deleted_at', 'Deleted At:'); ?>

    <p><?php echo $job->deleted_at; ?></p>
</div>

<?php /**PATH C:\xampp\htdocs\laravel-jobs\resources\views/jobs/show_fields.blade.php ENDPATH**/ ?>